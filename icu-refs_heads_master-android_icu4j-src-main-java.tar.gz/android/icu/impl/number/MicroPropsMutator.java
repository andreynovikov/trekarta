/* GENERATED SOURCE. DO NOT MODIFY. */
// © 2017 and later: Unicode, Inc. and others.
// License & terms of use: http://www.unicode.org/copyright.html#License
package android.icu.impl.number;

/**
 * @author sffc
 * @hide Only a subset of ICU is exposed in Android
 *
 */
public interface MicroPropsMutator<T> {

    public void mutateMicros(MicroProps micros, T value);

}
